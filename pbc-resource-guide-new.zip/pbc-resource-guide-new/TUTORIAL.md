# Updating the PBC Resource Guide: A Step-by-Step Tutorial

This guide teaches you how to add, edit, or remove resources on the PBC
Resource Guide website. No coding experience is required for small edits.
Bulk updates from a new spreadsheet require one free program to be
installed, but the steps are laid out below in full.

There are **two ways** to update the site — pick whichever fits what
you're doing:

| | Best for | Needs software installed? |
|---|---|---|
| **Method A** | Fixing one resource, adding a single new one, or removing one | No — just a web browser |
| **Method B** | Refreshing the *whole* site from an updated spreadsheet (many changes at once) | Yes — a free, one-time install |

Both methods end the same way: you save a file called `resources_data.js`
and upload it to the website's GitHub repository, which updates the live
site automatically within a minute or two.

---

## Before you start: how the site is organized

The live website is one small folder of files sitting in a GitHub
repository. The only file that ever needs to change during normal use is:

```
resources_data.js   ← this is the entire database of resources
```

Everything else (`index.html`, `styles.css`, `app.js`, etc.) is the
"engine" of the site and shouldn't need to change for a data update.

---

## Method A — Quick edits, directly on GitHub.com

Use this for adding one resource, correcting a phone number, updating
hours for one location, or removing an organization that's closed. You
don't need to install anything — you'll do this right in your browser.

### Step 1 — Open the file on GitHub
1. Go to your repository on GitHub.com (ask whoever set up the site for
   the link if you don't have it — it will look like
   `github.com/YOUR-ORG/pbc-resource-guide`).
2. Click on `resources_data.js` in the file list.
3. Click the **pencil (✏️) icon** in the top-right of the file view to
   edit it. (You'll need a free GitHub account and to be added as a
   collaborator on the repo — ask your GitHub repo owner to add you under
   **Settings → Collaborators** if you don't see the pencil icon.)

### Step 2 — Find the resource you want to change
Use your browser's find tool (**Ctrl+F** on Windows, **Cmd+F** on Mac) and
search for the organization's name. Every resource is one block that
looks like this:

```js
{
 "id": 187,
 "name": "Example Organization",
 "description": "What they do, in a sentence or two.",
 "services": ["Housing", "Food"],
 "primaryCategory": "Housing",
 "phone": "(561) 555-0100",
 "contactRaw": "(561) 555-0100, ext. 2, intake@example.org",
 "address": "123 Main St, West Palm Beach, FL 33401",
 "website": "https://example.org/",
 "eligibility": "Who qualifies.",
 "mustHave": "What the client needs to bring.",
 "referralText": "How to make the referral.",
 "referralLink": null,
 "hoursRaw": "Mon - Fri: 9 AM - 5 PM",
 "lat": 26.7153,
 "lng": -80.0534,
 "hasCoords": true,
 "noAddressReason": null,
 "isSO": false,
 "isEmergency": false
},
```

### Step 3 — Make your change
Edit the text between the quotation marks for whichever field needs to
change. A field reference table is below if you're not sure what a field
does.

**A few formatting rules to keep in mind, or the site may break:**
- Keep every value inside its matching quotation marks (`"..."`).
- Keep the comma at the end of every line **except the very last line**
  inside a `{ }` block.
- If your text itself contains a quotation mark (`"`), put a backslash
  right before it, like `\"`. (This is rare — most descriptions won't need
  it.)
- Don't delete the curly braces `{ }` or square brackets `[ ]`.

### Step 4 — Adding a brand-new resource
Copy an entire existing block (from `{` to the matching `}`, including the
comma after it), paste it right after another block, and edit every field
inside it. Give it a unique `id` number — one higher than the current
highest number in the file is a safe bet (use Ctrl+F to search `"id":` a
few times near the end of the file to see the last one used).

To remove a resource entirely, delete its whole block from the opening
`{` to the closing `},`.

### Step 5 — Save your change
1. Scroll to the bottom of the page.
2. Under "Commit changes," add a short note describing what you changed
   (e.g. "Update phone number for XYZ Shelter").
3. Click **Commit changes directly to the `main` branch.**

That's it — GitHub Pages will automatically rebuild the live site, which
usually takes 30–90 seconds. Refresh the website to see your update.

---

## Field reference (for Method A edits)

| Field | What it is | Example |
|---|---|---|
| `name` | Organization name shown everywhere | `"New Hope Shelter"` |
| `description` | 1–2 sentence summary shown in the popup | `"Emergency shelter and case management."` |
| `services` | List of categories — pick from the table below | `["Housing", "Food"]` |
| `primaryCategory` | The main one of the list above — controls the map pin's icon/color | `"Housing"` |
| `phone` | Just the main number, used for the one-tap "Call" button | `"(561) 555-0100"` |
| `contactRaw` | The **full** contact block — every phone, extension, and email you want visible in the popup | `"(561) 555-0100 ext. 4, intake@example.org"` |
| `address` | Full street address | `"123 Main St, West Palm Beach, FL 33401"` |
| `website` | Full web address, starting with `https://` (leave as `""` if none) | `"https://example.org/"` |
| `eligibility` | Who qualifies | `"PBC residents, 18+"` |
| `mustHave` | What the client needs to bring/have | `"Photo ID, proof of income"` |
| `referralText` | How a caseworker makes the referral | `"Call ahead to confirm bed availability."` |
| `referralLink` | A referral form URL, or `null` if there isn't one | `null` |
| `hoursRaw` | Hours, spreadsheet-style — the site automatically turns this into a clean weekly table | `"Mon - Fri: 9 AM - 5 PM"` |
| `lat` / `lng` | Map coordinates — see below for how to find these | `26.7153` / `-80.0534` |
| `hasCoords` | `true` if you filled in `lat`/`lng`, otherwise `false` | `true` |
| `noAddressReason` | `"virtual"` if it's an online-only service, `"contact"` if the address is intentionally withheld (client must call), or `null` if it has a normal address | `null` |
| `isSO` | `true` only if this is a sex-offender-specific service | `false` |
| `isEmergency` | `true` only if it's a genuine 24/7 shelter, crisis line, or walk-in service — this controls whether it shows up in the "🆘 I need help right now" fast-lane | `false` |

**Available categories for `services`/`primaryCategory`:**
`Housing`, `Food`, `Substance Use`, `Mental Health`, `Medical`,
`Family/Child Services`, `Employment`, `Education`, `Reentry`,
`Referrals`, `Benefits`, `Transportation`, `Court Requirements`, `Other`
(spelling and capitalization must match exactly).

### Finding `lat` and `lng` for a new address
1. Go to [Google Maps](https://maps.google.com) and search the address.
2. Right-click the exact spot on the map.
3. Click the top entry in the menu that appears — it's the coordinates
   (e.g. `26.715300, -80.053400`) — this copies them to your clipboard.
4. The first number is `lat`, the second is `lng`.

If a resource doesn't have a public address (a hotline, a telehealth
service, or a program that withholds its address for client safety), set:
```
"lat": null,
"lng": null,
"hasCoords": false,
"noAddressReason": "virtual",   // or "contact" — see table above
```

---

## Method B — Refreshing the whole site from a new spreadsheet

Use this when the Social Services team's master spreadsheet has had a lot
of changes — several new organizations, several closures, a re-organized
category list — and re-typing every change by hand (Method A) would take
too long. This regenerates `resources_data.js` from scratch based on the
spreadsheet.

### What you'll need (one-time setup)
- **Python 3**, a free program. If you're not sure whether you have it,
  open a terminal (Mac: Terminal app; Windows: search "Command Prompt")
  and type `python3 --version`. If you see a version number, you're set —
  if not, download it from
  [python.org/downloads](https://www.python.org/downloads/) and install it
  (accept the default options).
- One free Python add-on called **BeautifulSoup**. You'll install it with
  one command in Step 2 below.

### Step 1 — Export the spreadsheet
1. Open the master Google Sheet.
2. Make sure the tab containing **every** organization (not a
   category-specific tab) is named so that when exported it will be called
   `All` — check the tab's name at the bottom of the sheet.
3. Go to **File → Download → Web Page (.html, zipped)**.
4. This downloads a `.zip` file — unzip it. Inside, you'll find a file
   named `All.html` among others.

### Step 2 — Get the tools ready
1. Download the project's `build_data.py` script (it's included in the
   website's repository — download it from GitHub, or ask whoever built
   the site for it) and put it in the **same folder** as `All.html`.
2. Open a terminal in that folder:
   - **Mac:** open the folder in Finder, right-click, choose
     "New Terminal at Folder" (or open Terminal and type `cd ` followed by
     dragging the folder into the window, then press Enter).
   - **Windows:** open the folder in File Explorer, click the address bar,
     type `cmd`, and press Enter.
3. Install BeautifulSoup (only needed the very first time):
   ```
   pip install beautifulsoup4
   ```

### Step 3 — Run the script
In that same terminal, run:
```
python3 build_data.py
```
You should see a summary like:
```
Wrote 191 resources to resources_data.js
  - 176 with map coordinates
  - 14 virtual / contact-for-address
  - 23 SO-specific
  - 22 flagged as 24/7 emergency / walk-in
```
This confirms it worked, and gives you a sanity-check count. A brand new
`resources_data.js` file now sits in that same folder.

### Step 4 — Spot-check a few entries (recommended)
Before publishing, it's worth double-checking a handful of things the
script does automatically, since it can't read minds:
- **New addresses without coordinates:** if a new organization's address
  wasn't in a column the script recognizes, it will show up as "Contact
  for Address" on the live site instead of on the map. Check the
  "Virtual / Contact for Address" tab after publishing to confirm nothing
  landed there by mistake — see [Finding lat/lng](#finding-lat-and-lng-for-a-new-address)
  above if you need to fix one by hand afterward (Method A works fine for
  small touch-ups like this).
- **The 🆘 emergency list:** the script flags a resource as emergency
  (`isEmergency: true`) only when its hours say `24/7` *and* it's tagged
  Housing, Substance Use, or Mental Health, or when its name/description
  contains a word like "hotline" or "walk-in." Skim this list on the live
  site after publishing — it's the list someone in crisis will see, so
  it's worth a second look every time the spreadsheet changes
  significantly.
- **The 🔒 SO-Specific tab:** the script flags anything with "(SO)" or
  "sex offender" in its text. Skim this list too after a big update.

### Step 5 — Publish it
1. Go to your repository on GitHub.com.
2. Click on `resources_data.js` in the file list, then the pencil (✏️)
   icon to edit it.
3. Select all the existing text (Ctrl+A / Cmd+A) and delete it.
4. Open your newly-generated `resources_data.js` file (from Step 3) in
   any plain text editor, select all its text, copy it, and paste it into
   the GitHub editor.
5. Scroll down, add a commit message like "Refresh data from July
   spreadsheet update," and click **Commit changes directly to the `main`
   branch.**

The live site updates automatically within a minute or two.

---

## Testing a change before it goes live (optional but recommended for big updates)

If you want to preview your updated `resources_data.js` before publishing
it to the real site:
1. Download the whole website folder from GitHub (green **Code** button →
   **Download ZIP**) and unzip it.
2. Replace the `resources_data.js` inside that folder with your new one.
3. Open a terminal in that folder and run:
   ```
   python3 -m http.server 8000
   ```
4. Open `http://localhost:8000` in your browser to preview it exactly as
   it will look live. Close the terminal window when you're done — this
   preview only runs on your own computer and isn't visible to anyone
   else.

---

## Troubleshooting

**"The site looks broken / blank after I edited `resources_data.js` on
GitHub."**
This almost always means a stray comma, missing quotation mark, or
missing bracket was introduced during a Method A edit. GitHub has a
**"Preview" / "Raw"** view, but the easiest fix is: go back into the file,
find the block you just edited, and carefully compare it against another
block's punctuation (every field needs a comma after it except the last
one in a block, every value needs matching quotation marks). If in doubt,
undo your change (GitHub keeps every past version — click **History** at
the top of the file page, and you can view or restore an older version).

**"`python3 build_data.py` says `ModuleNotFoundError: No module named
'bs4'`."**
Run `pip install beautifulsoup4` again — if that doesn't work, try
`pip3 install beautifulsoup4` instead.

**"`python3 build_data.py` says `Couldn't find All.html`."**
Make sure `build_data.py` and `All.html` are in the exact same folder,
and that the sheet tab really is named so it exports as `All.html` (check
for typos or extra spaces in the tab name).

**"A new resource isn't showing up on the map."**
Check that `hasCoords` is `true` and that `lat`/`lng` are filled in
(not `null`). If the address wasn't recognized during a Method B refresh,
it will default to `"noAddressReason": "contact"` — add coordinates by
hand (Method A, using the [lat/lng lookup steps above](#finding-lat-and-lng-for-a-new-address))
to get it back on the map.

---

## Quick-reference checklist

**Small edit (one resource):**
☐ Open `resources_data.js` on GitHub → ☐ edit the one field → ☐ check
punctuation → ☐ commit.

**Big refresh (new spreadsheet):**
☐ Export sheet as `All.html` → ☐ run `python3 build_data.py` → ☐ check the
summary counts → ☐ spot-check the Virtual/Contact tab, 🆘 list, and 🔒 SO
tab → ☐ paste the new file into GitHub → ☐ commit.
