"""
Regenerates resources_data.js from a fresh Google Sheets export.

Usage:
    1. In Google Sheets: File -> Download -> Web page (.html, zipped)
    2. Unzip it into this folder (it will include an "All.html" file --
       that's the sheet tab with every organization listed).
    3. Run:  python3 build_data.py
       (requires: pip install beautifulsoup4)
    4. It writes a new resources_data.js right here. Re-upload that one
       file to your GitHub repo and the live site will reflect the update.
"""
import json
import re
import sys
from bs4 import BeautifulSoup

SOURCE_HTML = 'All.html'
OUTPUT_JS = 'resources_data.js'

CATEGORY_ICONS = {
    'Housing': '🏠', 'Food': '🍎', 'Substance Use': '❤️', 'Mental Health': '🧠',
    'Medical': '⚕️', 'Family/Child Services': '👨‍👩‍👧', 'Employment': '💼',
    'Education': '🎓', 'Reentry': '🔑', 'Referrals': '🔗', 'Benefits': '💳',
    'Transportation': '🚌', 'Court Requirements': '⚖️', 'Other': '📌',
}

VIRTUAL_KEYWORDS = ['online', 'telehealth', 'website', 'app-based']
VIRTUAL_NAMES = {
    'Vital Check -- Online records requests', 'Healthcare.gov',
    'Medicare (through Social Security)', 'Charlie Health',
}
HOTLINE_RE = re.compile(r'hotline|crisis line|\b988\b|suicide prevention', re.I)
WALKIN_RE = re.compile(r'walk-in|walk in (service|intake|welcome)', re.I)
TWENTYFOURSEVEN_RE = re.compile(r'^\s*24\s*/\s*7\s*$|24 hours.*7 days|24-hour', re.I)
ADMIN_BLACKLIST = {
    'Medicaid Complaints', 'Vital Check -- Online records requests', 'Healthcare.gov',
    'Medicare (through Social Security)', 'Social Security Administration', 'Next Level U',
}
EMERGENCY_ELIGIBLE_CATEGORIES = {'Housing', 'Substance Use', 'Mental Health'}


def cell_text(c):
    return c.get_text(separator=' ', strip=True).replace('\u200b', '').strip()


def cell_link(c):
    a = c.find('a')
    return a.get('href') if (a and a.get('href')) else None


def extract_phone(contact):
    m = re.search(r'(\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4})', contact)
    return m.group(1) if m else ''


def main():
    try:
        with open(SOURCE_HTML, encoding='utf-8') as f:
            soup = BeautifulSoup(f.read(), 'html.parser')
    except FileNotFoundError:
        print(f"Couldn't find {SOURCE_HTML}. See the instructions at the top of this file.")
        sys.exit(1)

    table = soup.find_all('table')[0]
    rows = table.find_all('tr')

    records = []
    # Row 0 = spreadsheet column letters, row 1 = real headers, row 2 = spacer, data starts row 3
    for r in rows[3:]:
        cells = r.find_all(['td', 'th'])
        if len(cells) < 17:
            continue
        org = cell_text(cells[1])
        if not org:
            continue
        records.append({
            'row_id': cell_text(cells[0]), 'organization': org, 'description': cell_text(cells[2]),
            'services_raw': cell_text(cells[3]), 'contact': cell_text(cells[4]), 'address': cell_text(cells[5]),
            'website_text': cell_text(cells[6]), 'website_link': cell_link(cells[6]),
            'eligibility': cell_text(cells[7]), 'must_have': cell_text(cells[8]),
            'referral_text': cell_text(cells[9]), 'referral_link': cell_link(cells[9]),
            'hours_raw': cell_text(cells[10]), 'lat': cell_text(cells[15]), 'lng': cell_text(cells[16]),
        })

    out = []
    for i, r in enumerate(records):
        services = [p.strip() for p in r['services_raw'].split(',') if p.strip()] or ['Other']
        primary = services[0] if services[0] in CATEGORY_ICONS else 'Other'

        try:
            lat = float(r['lat']) if r['lat'] else None
            lng = float(r['lng']) if r['lng'] else None
        except ValueError:
            lat = lng = None
        has_coords = lat is not None and lng is not None

        blob = ' '.join([r['organization'], r['description'], r['eligibility'], r['must_have']])
        is_so = bool(re.search(r'\(SO\)|sex offender', blob, re.I))

        is_hotline = bool(HOTLINE_RE.search(blob))
        is_walkin = bool(WALKIN_RE.search(blob))
        is_247 = bool(TWENTYFOURSEVEN_RE.search(r['hours_raw']))
        is_emergency = False
        if r['organization'] not in ADMIN_BLACKLIST and not is_so:
            if is_hotline or is_walkin:
                is_emergency = True
            elif is_247 and primary in EMERGENCY_ELIGIBLE_CATEGORIES:
                is_emergency = True

        no_address_reason = None
        if not has_coords:
            blob_lower = (r['organization'] + ' ' + r['description']).lower()
            if r['organization'] in VIRTUAL_NAMES or any(k in blob_lower for k in VIRTUAL_KEYWORDS):
                no_address_reason = 'virtual'
            else:
                no_address_reason = 'contact'

        out.append({
            'id': i + 1, 'name': r['organization'], 'description': r['description'],
            'services': services, 'primaryCategory': primary,
            'phone': extract_phone(r['contact']), 'contactRaw': r['contact'], 'address': r['address'],
            'website': r['website_link'] or (r['website_text'] if r['website_text'].startswith('http') else ''),
            'eligibility': r['eligibility'], 'mustHave': r['must_have'],
            'referralText': r['referral_text'], 'referralLink': r['referral_link'],
            'hoursRaw': r['hours_raw'], 'lat': lat, 'lng': lng, 'hasCoords': has_coords,
            'noAddressReason': no_address_reason, 'isSO': is_so, 'isEmergency': is_emergency,
        })

    with open(OUTPUT_JS, 'w', encoding='utf-8') as f:
        f.write('// Auto-generated by build_data.py from the PBC Resource Guide spreadsheet.\n')
        f.write('// Do not hand-edit if you plan to re-run the script -- your edits will be overwritten.\n')
        f.write('const PBC_RESOURCES = ')
        json.dump(out, f, indent=1, ensure_ascii=False)
        f.write(';\n')

    print(f"Wrote {len(out)} resources to {OUTPUT_JS}")
    print(f"  - {sum(1 for o in out if o['hasCoords'])} with map coordinates")
    print(f"  - {sum(1 for o in out if o['noAddressReason'])} virtual / contact-for-address")
    print(f"  - {sum(1 for o in out if o['isSO'])} SO-specific")
    print(f"  - {sum(1 for o in out if o['isEmergency'])} flagged as 24/7 emergency / walk-in")


if __name__ == '__main__':
    main()
