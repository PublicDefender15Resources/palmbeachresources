# PBC Resource Guide

A resource-referral map built for the Palm Beach County Public Defender's
Office, Social Services Division. It turns the team's resource spreadsheet
into a searchable, filterable, Google-Maps-style tool that caseworkers can
use to find and refer nearby services for clients.

**This is a static website — no server, database, or build step required.**
It runs entirely in the browser, which makes it free and simple to host on
GitHub Pages.

---

## 1. Deploying to GitHub Pages (5 minutes)

1. Create a new **public** repository on GitHub (e.g. `pbc-resource-guide`).
2. Upload every file in this folder (`index.html`, `styles.css`, `app.js`,
   `hours-and-categories.js`, `resources_data.js`) to the root of that
   repository. Easiest way: on the repo page, click **Add file → Upload
   files**, drag all five files in, and commit.
3. In the repository, go to **Settings → Pages**.
4. Under "Build and deployment," set **Source** to `Deploy from a branch`,
   branch `main`, folder `/ (root)`. Click **Save**.
5. GitHub will give you a live URL, usually
   `https://YOUR-USERNAME.github.io/pbc-resource-guide/` — it can take a
   minute or two to go live the first time.
6. Share that link with the Social Services team. No installation needed —
   it works in any modern desktop browser (Chrome, Edge, Safari, Firefox).

That's it — the whole app is five plain files, so there's nothing else to
configure, and no ongoing hosting cost.

### Testing locally before you deploy
Because browsers block a page from loading its own local files via
`file://`, you need a tiny local server to preview it (this is normal for
any web app, not a bug). From inside this folder, run either:

```
python3 -m http.server 8000
```
or, if you have Node installed:
```
npx serve .
```
Then open `http://localhost:8000` in your browser.

---

## 2. What's inside

| File | Purpose |
|---|---|
| `index.html` | Page structure — top bar, sidebar, map, popups |
| `styles.css` | All visual styling (colors, fonts, layout) |
| `app.js` | App logic — filtering, search, map markers, directions, modal |
| `hours-and-categories.js` | Converts messy "Mon & Wed: 8-8, Tues..." hours text into a clean weekly table; category icon/color definitions |
| `resources_data.js` | The actual resource data, generated from your spreadsheet (see below) |

The map uses **Leaflet** (open-source, no API key or account needed) with a
light "Positron" basemap, and **Leaflet.markercluster** to keep pins from
overlapping when several organizations sit close together. Both are loaded
from a free CDN, so an internet connection is required for the map tiles
and marker library to load (the resource list and search still work if
that connection briefly drops — see below).

---

## 3. Feature guide

- **Map search ("Find Nearby")** — type any Palm Beach County address in
  the top bar. It geocodes the address (via OpenStreetMap's free Nominatim
  service), centers the map there, drops a pin, and sorts every visible
  resource by walking distance.
- **🆘 "I need help right now"** — the floating button in the bottom-right
  of the map. It instantly filters to 24/7 shelters, crisis/detox
  facilities, and walk-in mental-health/substance-use services, and shows
  a banner confirming the filtered view. Click "Exit Emergency View" to
  return to normal browsing.
- **Sidebar width toggle** — the icon button at the top-left cycles the
  sidebar between full detail cards, a compact view, and an icon-only rail,
  so caseworkers can reclaim map space when they don't need the full list.
- **Category filter chips** — click any category (Housing, Food, Substance
  Use, etc.) to narrow the list and map; click several to combine them;
  click "All" to reset.
- **🌐 Virtual / Contact for Address tab** — resources that don't have a
  public street address (telehealth services, or programs — like some
  domestic-violence and reentry housing — that intentionally withhold
  their address for client safety and require a phone call first).
- **🔒 SO-Specific Services tab** — every resource in the spreadsheet
  tagged for registered sex offenders, gathered in one place.
- **Map pins** — one small icon per category (🏠 housing, 🍎 food, ❤️
  substance use, etc.), clustered into numbered circles when zoomed out so
  the map doesn't get cluttered. Click a pin (or a sidebar card) to open a
  popup with the full write-up: description, eligibility requirements,
  referral instructions, a clean hours table, and one-tap directions.
- **"How to get there"** — every resource's popup includes walking and
  transit directions links that open directly in Google Maps or Apple
  Maps, since many clients don't have a car.

---

## 4. Updating the data

The data started as an export of your Google Sheet. When the spreadsheet
changes, regenerate `resources_data.js` rather than hand-editing it:

1. In Google Sheets: **File → Download → Web Page (.html, zipped)**.
2. Unzip it, and make sure the sheet tab with *all* organizations is named
   so its exported file is called `All.html` (this is the sheet the build
   script reads).
3. Run the build script included here, `build_data.py` (requires Python 3
   and `pip install beautifulsoup4`):
   ```
   python3 build_data.py
   ```
   It reads `All.html`, cleans it up, and writes a new `resources_data.js`
   into the `site/` folder — re-upload that one file to GitHub and you're
   done.

If you'd rather not run Python, you can also hand-edit `resources_data.js`
directly — it's a plain JSON array. Each resource looks like this:

```js
{
  "id": 999,
  "name": "Example Organization",
  "description": "What they do, in a sentence or two.",
  "services": ["Housing", "Food"],
  "primaryCategory": "Housing",
  "phone": "(561) 555-0100",
  "contactRaw": "(561) 555-0100, ext. 2",
  "address": "123 Main St, West Palm Beach, FL 33401",
  "website": "https://example.org/",
  "eligibility": "Who qualifies.",
  "mustHave": "What the client needs to bring.",
  "referralText": "How to make the referral.",
  "referralLink": null,
  "hoursRaw": "Mon - Fri: 9 AM - 5 PM",
  "lat": 26.7153,
  "lng": -80.0534,
  "hasCoords": true,
  "noAddressReason": null,        // "virtual", "contact", or null
  "isSO": false,
  "isEmergency": false
}
```

To find `lat`/`lng` for a new address, search the address on
google.com/maps, right-click the pin, and click the coordinates that
appear at the top of the menu to copy them.

---

## 5. A couple of honest notes

- **Font:** You asked for Footlight MT Light. It's a licensed
  Microsoft/Adobe font that can't legally be embedded in a public website,
  so this build uses **Nunito** (free, from Google Fonts) — a similarly
  warm, rounded, friendly typeface at a larger-than-default size for
  readability. If your office has a licensed web-font version of
  Footlight, you can swap the Google Fonts `<link>` in `index.html` and
  update the `--font-body` variable in `styles.css`, and everything else
  will pick it up automatically.
- **"24/7 / crisis / walk-in" tagging:** The emergency fast-lane filter was
  built by pattern-matching your spreadsheet's hours and descriptions
  (explicit "24/7" hours combined with Housing, Substance Use, or Mental
  Health categories, or explicit hotline/walk-in wording). It's a good
  starting point, but please have a staff member skim the "🆘" list once
  after deploying to confirm nothing's missing or miscategorized — that
  list literally guides someone in crisis, so it's worth a second set of
  eyes.
- **Sex-offender tagging** was likewise done by detecting "(SO)" and "sex
  offender" wording in the spreadsheet — worth a similar quick review.
- The map itself needs an internet connection to load its tiles (like any
  online map). If that connection drops, the app is built to fail
  gracefully: the resource list, search, filters, and detail popups all
  keep working — only the visual map degrades.
